package project;
import java.util.*;
public class OrderingSystem {

	
	Scanner scanner = new Scanner(System.in);
	public  String again;
	public  int choose;
	public  int quantity = 1;
	public  double total=0,pay;
	public  int choice;
	OrderingSystem(String again,int choice,int quantity,double total,double pay,int choose){
		this.again=again;
		this.choice=choice;
		this.quantity=quantity;
		this.total=total;
		this.pay=pay;
		this.choose=choose;
	}
	public OrderingSystem() {
		// TODO Auto-generated constructor stub
	}
	public static void menu() {
		System.out.println("\t\t\t\t Welcome To FastFood Center");
		System.out.println("\t\t\t\t+========================+");
		System.out.println("\t\t\t\t   FastFood Menu     ");
		System.out.println("\t\t\t\t  1.Pizza               ");
		System.out.println("\t\t\t\t  a.Chicken Pizza   	Rs..180.00         ");
		System.out.println("\t\t\t\t  b.Veg Pizza       	Rs..100.00        ");
		System.out.println("\t\t\t\t  c.Jain Pizza      	Rs..130.00        ");
		System.out.println("");
		System.out.println("\t\t\t\t  2.Burger     ");
		System.out.println("\t\t\t\t  a.Chicken Burger  	Rs..120.00         ");
		System.out.println("\t\t\t\t  b.Veg Burger      	Rs..80.00        ");
		System.out.println("\t\t\t\t  c.Jain Burger     	Rs..90.00        ");
		System.out.println("");
		System.out.println("\t\t\t\t  3.Sandwich  ");
		System.out.println("\t\t\t\t  a.Chicken Sandwich    Rs..150.00         ");
		System.out.println("\t\t\t\t  b.Veg Sandwich        Rs..110.00        ");
		System.out.println("\t\t\t\t  c.Jain Sandwich       Rs..100.00        ");
		System.out.println("\t\t\t\t  4.Cancel              ");
		System.out.println("\t\t\t\t+========================+");
	}

	public  void order() {
		System.out.println("Press 1 for Pizza, Press 2 for Burger, Press 3 for Sandwich and Press 4 for Cancel");
		System.out.println("Press Number you want to buy? :");
		choose = scanner.nextInt();

		//conditions
		if(choose==1) {
			Pizza pizza = new Pizza(again,choice,quantity,total, pay, choose);
			pizza.createPizzaList();
		}
		
		
		else if(choose==2) {
			Burger burger = new Burger(again,choice,quantity,total, pay, choose);
			burger.createBurgerList();
		}

		

		// Sandwich
		else if(choose==3) {
			Sandwich sandwich=new Sandwich(again,choice,quantity,total, pay, choose);
			sandwich.createSanwich();
		}



		else if(choose==4) {

			System.out.println("You cancel the order...");
			System.exit(0);
		}
		else {
			System.out.println("Choose 1 to 4 code only! ");
			order();
		}


	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		menu();
		OrderingSystem orders=new OrderingSystem();
		orders.order();
		

	}

}


